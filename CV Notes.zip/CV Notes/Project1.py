# -*- coding: utf-8 -*-

'''
Detects Bricks, Balls, and Cylinders.
'''

# Import numpy.
import numpy as np
import matplotlib.image as mpimg #Map images.

# Convert to 0-1 grayscale values.
def convert_to_grayscale(im): 
    return np.mean(im, axis = 2)

# Scale Image
def scale_image_255(im):
    return (im/255)

# Map points on graph
def mapPoints(edges):
    '''    
    Parameters
    ----------
    edges : TYPE
        DESCRIPTION.

    Returns
    -------
    accumulator : TYPE
        DESCRIPTION.

    '''
    y_coords, x_coords = np.where(edges)
    y_coords_flipped = edges.shape[0] - y_coords
    
    phi_bins = 128
    theta_bins = 128
    accumulator = np.zeros((phi_bins, theta_bins))

    rho_min = -edges.shape[0]
    rho_max = edges.shape[1]
    
    theta_min = 0
    theta_max = np.pi
    
    #Compute the rho and theta values for the grids in our accumulator:
    rhos = np.linspace(rho_min, rho_max, accumulator.shape[0])
    thetas = np.linspace(theta_min, theta_max, accumulator.shape[1])
   
    for i in range(len(x_coords)):
        x = x_coords[i]
        y = y_coords_flipped[i]

        curve_rhos = x*np.cos(thetas)+y*np.sin(thetas)

        for j in range(len(thetas)):
            if np.min(abs(curve_rhos[j]-rhos)) <= 1.0:
                rho_index = np.argmin(abs(curve_rhos[j]-rhos))
                accumulator[rho_index, j] += 1
                if accumulator [rho_index, j] > 120:
                    return accumulator
                
    max_value = np.max(accumulator)
    relative_thresh = 0.35

    rho_max_indices, theta_max_indices,  = np.where(accumulator > relative_thresh * max_value)
    
    return accumulator

def getKx():
    return np.array([[1, 0, -1],
               [2, 0, -2],
               [1, 0, -1]])
def getKy():
    return np.array([[1, 2, 1],
               [0, 0, 0],
               [-1, -2, -1]])

def filter_2d(im, kernel):
    '''    
    Filter an image by taking the dot product of each 
    image neighborhood with the kernel matrix.
    Args:
    im = (H x W) grayscale floating point image
    kernel = (M x N) matrix, smaller than im
    Returns: 
    (H-M+1 x W-N+1) filtered image.
    '''

    M = kernel.shape[0] 
    N = kernel.shape[1]
    H = im.shape[0]
    W = im.shape[1]
    
    filtered_image = np.zeros((H-M+1, W-N+1), dtype = 'float64')
        
    # Iterate through each i,j pixel. This moves down or right 1 pixel at a time.
    for i in range(filtered_image.shape[0]):
        for j in range(filtered_image.shape[1]):
            image_patch = im[i:i+M, j:j+N]            
            filtered_image[i, j] = np.sum(np.multiply(image_patch, kernel))
                                   
    return filtered_image

def classify(image):
    
    object = "brick"
     
    #Get scaled image.
    scaledImage = scale_image_255(image)
    #Get grayscale image.
    image = convert_to_grayscale(scaledImage)
    # Use Sobel Operator - Vertical.
    '''
    The reason we only use one the gien vertica/horizontal operators is to save time.
    We only use Gx, which gives us lines the (x) horizontal direction. 
    We know that only bricks have horizontal lines.
    Balls do not have horizontal lines.
    Cylinders do not have horizontal lines, but they do have vertical lines. 
    
    If a horizontal line is detected, it is most likely a brick.
    Only bricks have horizontal lines.     
    '''
    Gx = filter_2d(image, getKx())
    #Get direction.
    G  = np.sqrt(Gx**2)            
    #Replace pixels with gradient estimates above thresh 
    #with the direction of the gradient estimate:
    edges = G > 1
    image = mapPoints(edges)
    #Get max value for hough space.
    max_value = np.max(image)
    '''
    If no horizontal lines are detected, we only have to 
    guess ball or cylinder.
    This makes it a little easier to use the hough transform values.                

    Balls and Cylinders have very similar values in the 60-110 ranges.                            
    We need another approach for these.
    
    We now implement the next direction to use Gy.
    We now use Gy to get the vertical direction.
    Balls do not have vertical lines.
    Cylinders do have vertical lines.
    
    If vertical lines are detetected, return a cylinder.
    '''    
    if(max_value > 110):
        object = "brick"
    elif (max_value < 60):
        object = "ball"    
    else:
        # Horizontal Detection.
        Gy = filter_2d(image, getKy())
        #Get directions.
        G  = np.sqrt(Gx**2 + Gy**2) 
        edges = G > 1.05
        image = mapPoints(edges)
        max_value = np.max(image)
        #Determine Object.
        if(max_value > 110):
            object = "brick"
        elif (max_value < 60):
            object = "ball"
        else:
            object = "cylinder"
    
    #Return object string.
    return object

# This is just to test the program.
def main():
    image = mpimg.imread('data/easy/brick/brick_1.jpg') 
    image = classify(image)
    print(image);
    
main()