# -*- coding: utf-8 -*-

import numpy as np

def breakIntoGrids(im, s = 9):
    '''
    Break overall image into overlapping grids of size s x s, s must be odd.
    '''
    grids = []

    h = s//2 #half grid size minus one.
    for i in range(h, im.shape[0]-h):
        for j in range(h, im.shape[1]-h):
            grids.append(im[i-h:i+h+1,j-h:j+h+1].ravel())

    return np.vstack(grids)

def reshapeIntoImage(vector, im_shape, s = 9):
    '''
    Reshape vector back into image. 
    '''
    h = s//2 #half grid size minus one. 
    image = np.zeros(im_shape)
    image[h:-h, h:-h] = vector.reshape(im_shape[0]-2*h, im_shape[1]-2*h)

    return image

def filter_2d(data):
    
    # Stores the number of blobs and their pixel values. 
    blobs = []
    # We initialize with 2.
    blob = 2
    
    #print(data.shape[0])
    #print(data.shape[1])
    for x in range(26):
        for y in range(data.shape[1]):            
            if data[x, y] > 0.5:
                if x > 0.5 and y > 0.5 and data[x, y-1] > 0.5 and data[x-1, y] > 0.5 and data[x-1, y] != data[x, y-1]:
                    data[x, y] = data[x, y - 1]
                    blobs.remove(data[x - 1, y])
                    data[data == data[x - 1, y]] = data[x, y]
                elif x > 0.5 and data[x-1, y] > 0.5:
                    data[x, y] = data[x-1, y]
                elif x > 0.5 and data[x, y-1] > 0.5:
                    data[x, y] = data[x, y-1]
                else:
                    data[x, y] = blob
                    blobs.append(blob)
                    blob += 1
                    
    return blobs

def count_fingers(im): 
    
    # Get image into grayscale and grid format.
    grayscale_image = im
    im = grayscale_image > 92
    X = breakIntoGrids(im, s = 9)
    
    #Tree rule.
    treeRule1 = lambda X: np.logical_and(np.logical_and(X[:, 40] == 1, X[:,0] == 0), X[:, 53] == 0)
    yhat = treeRule1(X)
    yhat_reshaped = reshapeIntoImage(yhat, im.shape)
    
    numFingers = filter_2d(yhat_reshaped)
   
    numFingers = len(numFingers)
    
    return numFingers
    
    

